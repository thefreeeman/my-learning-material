package Bar;
use Mo;
extends 'Foo';
1;
