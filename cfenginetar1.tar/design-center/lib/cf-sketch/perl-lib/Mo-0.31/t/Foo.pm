package Foo;
use Mo;

has 'stuff';

1;
